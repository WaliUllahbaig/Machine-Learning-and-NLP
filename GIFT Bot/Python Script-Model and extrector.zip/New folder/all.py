import threading
import time
import os
import csv
import imaplib
import email
import pickle
import pandas as pd
from flask import Flask, jsonify, request
import re
import warnings
import spacy
import nltk
from spacy.lang.en.stop_words import STOP_WORDS
from nltk.corpus import stopwords
import datefinder
from datetime import datetime
import datetime



warnings.filterwarnings("ignore")
nltk.download('stopwords')
nlp = spacy.load("en_core_web_sm", disable=['parser', 'tagger', 'ner'])
stops = STOP_WORDS
spec_chara = re.compile('[(){}\[\]\|,;]')
ext_sym = re.compile('[^0-9a-z @/: -]')

def clean(words):
    if isinstance(words, str):
        words = words.lower()
        words = spec_chara.sub(' ', words)
        words = ext_sym.sub('', words)
        words = ' '.join(word for word in words.split() if word not in stops)
    else:
        words = ''
    return words

def normalize(comment, lowercase, remove_stopwords):
    if isinstance(comment, str):
        if lowercase:
            comment = comment.lower()
            comment = spec_chara.sub(' ', comment)
            comment = ext_sym.sub('', comment)
        
        comment = nlp(comment)
        lemmatized = []
        
        for word in comment:
            lemma = word.lemma_.strip()
            
            if lemma:
                if not remove_stopwords or (remove_stopwords and lemma not in stops):
                    lemmatized.append(lemma)
        
        return " ".join(lemmatized)
    elif isinstance(comment, float):
        return str(comment)
    else:
        return ''

def preprocess_text(text):
    processed_text = text.apply(normalize, lowercase=True, remove_stopwords=True)
    processed_text = text.apply(clean)
    return processed_text

def extract_dates_from_text(text):
    matches = datefinder.find_dates(text)
    dates = list(matches)
    return dates[0] if dates else None

def get_timetuple(date_value):
    if pd.notna(date_value):
        return date_value.timetuple()
    return None

app1 = Flask(__name__)

def extract_emails_and_update_csv(username, password):
    mail = imaplib.IMAP4_SSL('imap.gmail.com')
    mail.login(username, password)
    mail.select('inbox')

    _, message_ids = mail.search(None, 'ALL')
    message_ids = message_ids[0].split()
    latest_message_ids = message_ids[:5]  # Retrieve the latest 5 message IDs

    email_data = []

    for message_id in latest_message_ids:
        _, data = mail.fetch(message_id, '(RFC822)')
        raw_email = data[0][1]
        email_message = email.message_from_bytes(raw_email)

        subject = email_message['Subject']
        sender = email_message['From']
        date = email_message['Date']
        to = email_message['To']

        text = ""

        if email_message.is_multipart():
            for part in email_message.get_payload():
                if part.get_content_type() == "text/plain":
                    text += part.get_payload()
        else:
            text = email_message.get_payload()

        date = extract_dates_from_text(text)

        email_data.append([subject, sender, date, to, text])
    mail.logout()

    csv_file_path = 'uploads/All Labelled Mails.csv'
    file_exists = os.path.exists(csv_file_path)

    with open(csv_file_path, 'a', newline='') as file:
        writer = csv.writer(file)
        if not file_exists:
            writer.writerow(['Subject', 'From', 'Date', 'To', 'Text'])
        writer.writerows(email_data)

def delete_existing_csv_file():
    csv_file_path = 'uploads/All Labelled Mails.csv'
    if os.path.exists(csv_file_path):
        os.remove(csv_file_path)

def start_extraction_scheduler(username, password):
    while True:
        delete_existing_csv_file()
        extract_emails_and_update_csv(username, password)
        time.sleep(60)  # Delay for 1 minute

# Define a POST route for extracting emails and making predictions
@app1.route('/extract_and_predict', methods=['POST'])
def extract_and_predict():
    try:
        request_data = request.get_json()
        username = request_data.get('username')
        password = request_data.get('password')

        if not username or not password:
            return jsonify({'error': 'Username and password are required'}), 400
        
        delete_existing_csv_file()

        extract_emails_and_update_csv(username, password)

        with open("vectorizer.pkl", "rb") as file:
            vectorizer = pickle.load(file)

        with open("model.pkl", "rb") as file:
            model = pickle.load(file)

        data = pd.read_csv("uploads/All Labelled Mails.csv")
        processed_text = preprocess_text(data['Text'])
        input_vector = vectorizer.transform(processed_text)
        y_pred = model.predict(input_vector)

        labeled_df = data[y_pred == 1]
        labeled_df = labeled_df[labeled_df['Date'].notna()]

        subject = labeled_df['Subject']
        From = labeled_df['From']
        To = labeled_df['To']
        Date = labeled_df['Text'].apply(extract_dates_from_text)
        text = labeled_df['Text']

        predicted_data = {
        'Subject': list(set(subject.tolist())),
        'From': list(set(From.tolist())),
        'Date': list(set(Date.tolist())),
        'To': list(set(To.tolist())),
        'Text': list(set(text.tolist()))
        }
        
        return jsonify(predicted_data)

    except Exception as e:
        return jsonify({'error': str(e)}), 500
app2 = Flask(__name__)

def extract_date_from_list(lst):
    for item in lst:
        if isinstance(item, datetime.datetime):
            return item.strftime('%Y-%m-%d')
    return None

@app2.route('/email_data', methods=['POST'])
def get_email_data():
    try:
        #request_data = request.get_json()
        #EMAIL =  '191870086@gift.edu.pk' # Get username from API request
        #PASSWORD =  'uppercase' # Get password from API request
        request_data = request.get_json()
        EMAIL = request_data.get('username')  # Get username from API request
        PASSWORD = request_data.get('password')

        if not EMAIL or not PASSWORD:
                return jsonify({'error': 'Username and password are required'}), 400
        # Extract the username from the email address
        username = EMAIL.split('@')[0]

            # Create a directory to save attachments
        if not os.path.exists('attachments'):
            os.makedirs('attachments')

        # Connect to the Gmail IMAP server
        mail = imaplib.IMAP4_SSL('imap.gmail.com')
        mail.login(EMAIL, PASSWORD)

        # Select the INBOX folder
        mail.select('inbox')

        # Search for emails with XLSX attachments
        status, email_ids = mail.uid('search', None, 'ALL')
        email_list = email_ids[0].split()
        email_list.reverse()  # To get the most recent emails first

        # List to store email data
        email_data_list = []

        # Process the latest 5 emails with XLSX attachments
        for email_id in email_list[:5]:
            status, email_data = mail.uid('fetch', email_id, '(RFC822)')

            if status == 'OK':
                raw_email = email_data[0][1]
                msg = email.message_from_bytes(raw_email)

                # Check if there are attachments
                has_attachment = False
                if msg.is_multipart():
                    for part in msg.walk():
                        content_type = part.get_content_type()

                        if 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' in content_type:
                            has_attachment = True
                            filename = part.get_filename()

                            if filename:
                                filepath = os.path.join('attachments', filename)

                                with open(filepath, 'wb') as f:
                                    f.write(part.get_payload(decode=True))

                                # Open the XLSX file
                                df = pd.read_excel(filepath)
                                data = []
                                for index, row in df.iterrows():
                                    if username in str(row.values):
                                        for cell in row:
                                            data.append(cell)

                                date = extract_date_from_list(data)
                                subject = msg["Subject"]
                                email_body = None
                                if msg.is_multipart():
                                    for part in msg.walk():
                                        if part.get_content_type() == "text/plain":
                                            email_body = part.get_payload(decode=True).decode()

                                email_data_list.append({
                                    "Subject": subject,
                                    "Date": date,
                                    "Body": email_body
                                })

        # Logout and close the connection
        mail.logout()

        return jsonify(email_data_list)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def run_app1():
    app1.run(host='localhost', port=5000)

def run_app2():
    app2.run(host='localhost', port=5001)

if __name__ == '__main__':
    thread1 = threading.Thread(target=run_app1)
    thread2 = threading.Thread(target=run_app2)

    # Start both threads
    thread1.start()
    thread2.start()


