from flask import Flask, jsonify, request
import imaplib
import email
import os
import pandas as pd
from datetime import datetime
import datetime

app = Flask(__name__)

def extract_date_from_list(lst):
    for item in lst:
        if isinstance(item, datetime.datetime):
            return item.strftime('%Y-%m-%d')
    return None

@app.route('/email_data', methods=['POST'])
def get_email_data():
    try:
        #request_data = request.get_json()
        #EMAIL =  '191870086@gift.edu.pk' # Get username from API request
        #PASSWORD =  'uppercase' # Get password from API request
        request_data = request.get_json()
        EMAIL = request_data.get('username')  # Get username from API request
        PASSWORD = request_data.get('password')

        if not EMAIL or not PASSWORD:
                return jsonify({'error': 'Username and password are required'}), 400
        # Extract the username from the email address
        username = EMAIL.split('@')[0]

            # Create a directory to save attachments
        if not os.path.exists('attachments'):
            os.makedirs('attachments')

        # Connect to the Gmail IMAP server
        mail = imaplib.IMAP4_SSL('imap.gmail.com')
        mail.login(EMAIL, PASSWORD)

        # Select the INBOX folder
        mail.select('inbox')

        # Search for emails with XLSX attachments
        status, email_ids = mail.uid('search', None, 'ALL')
        email_list = email_ids[0].split()
        email_list.reverse()  # To get the most recent emails first

        # List to store email data
        email_data_list = []

        # Process the latest 5 emails with XLSX attachments
        for email_id in email_list[:5]:
            status, email_data = mail.uid('fetch', email_id, '(RFC822)')

            if status == 'OK':
                raw_email = email_data[0][1]
                msg = email.message_from_bytes(raw_email)

                # Check if there are attachments
                has_attachment = False
                if msg.is_multipart():
                    for part in msg.walk():
                        content_type = part.get_content_type()

                        if 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' in content_type:
                            has_attachment = True
                            filename = part.get_filename()

                            if filename:
                                filepath = os.path.join('attachments', filename)

                                with open(filepath, 'wb') as f:
                                    f.write(part.get_payload(decode=True))

                                # Open the XLSX file
                                df = pd.read_excel(filepath)
                                data = []
                                for index, row in df.iterrows():
                                    if username in str(row.values):
                                        for cell in row:
                                            data.append(cell)

                                date = extract_date_from_list(data)
                                subject = msg["Subject"]
                                email_body = None
                                if msg.is_multipart():
                                    for part in msg.walk():
                                        if part.get_content_type() == "text/plain":
                                            email_body = part.get_payload(decode=True).decode()

                                email_data_list.append({
                                    "Subject": subject,
                                    "Date": date,
                                    "Body": email_body
                                })

        # Logout and close the connection
        mail.logout()

        return jsonify(email_data_list)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
